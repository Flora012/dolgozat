﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Dolgozat_Form
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            
        }

        

        

        private void Jelentkezes_Click(object sender, EventArgs e)
        {
            Form regForm = new Form();
            regForm.Text = "Katona Regisztráció";

            Label lastNameLabel = new Label { Text = "Vezetéknév:", Location = new Point(50, 50) };
            TextBox lastNameBox = new TextBox { Location = new Point(150, 50), Width = 200 };

            Label firstNameLabel = new Label { Text = "Keresztnév:", Location = new Point(50, 100) };
            TextBox firstNameBox = new TextBox { Location = new Point(150, 100), Width = 200 };

            Label emailLabel = new Label { Text = "Email:", Location = new Point(50, 150) };
            TextBox emailBox = new TextBox { Location = new Point(150, 150), Width = 200 };

            Label ageLabel = new Label { Text = "Kor:", Location = new Point(50, 200) };
            TextBox ageBox = new TextBox { Location = new Point(150, 200), Width = 200 };

            Button submitButton = new Button { Text = "Jelentkezés", Location = new Point(150, 250) };

            submitButton.Click += (s, ev) =>
            {
                if (string.IsNullOrWhiteSpace(lastNameBox.Text) || string.IsNullOrWhiteSpace(firstNameBox.Text) ||
                    string.IsNullOrWhiteSpace(emailBox.Text) || string.IsNullOrWhiteSpace(ageBox.Text))
                {
                    MessageBox.Show("Minden mezőt ki kell tölteni!");
                }
                else
                {
                    StoreApplicant(lastNameBox.Text, firstNameBox.Text, emailBox.Text, ageBox.Text);
                    MessageBox.Show("Jelentkezés sikeres!");
                    regForm.Close();
                }
            };

            regForm.Controls.Add(lastNameLabel);
            regForm.Controls.Add(lastNameBox);
            regForm.Controls.Add(firstNameLabel);
            regForm.Controls.Add(firstNameBox);
            regForm.Controls.Add(emailLabel);
            regForm.Controls.Add(emailBox);
            regForm.Controls.Add(ageLabel);
            regForm.Controls.Add(ageBox);
            regForm.Controls.Add(submitButton);

            regForm.ShowDialog();
        }

        private void StoreApplicant(string lastName, string firstName, string email, string age)
        {
            applicants.Add(new string[] { lastName, firstName, email, age });
        }

        private List<string[]> applicants = new List<string[]>();

        private void ShowAdminPanel()
        {
            Form adminPanel = new Form();
            adminPanel.Text = "Admin Felület";
            adminPanel.Size = new Size(500, 500);

            DataGridView dgv = new DataGridView();
            dgv.Location = new Point(20, 50);
            dgv.Size = new Size(450, 300);

            dgv.Columns.Add("LastName", "Vezetéknév");
            dgv.Columns.Add("FirstName", "Keresztnév");
            dgv.Columns.Add("Email", "Email");
            dgv.Columns.Add("Age", "Kor");

            foreach (var applicant in applicants)
            {
                dgv.Rows.Add(applicant);
            }

            adminPanel.Controls.Add(dgv);
            adminPanel.Show();
        }

        private void bejelentkezes(object sender, EventArgs e)
        {
            Form adminLoginForm = new Form();
            adminLoginForm.Text = "Admin Bejelentkezés";

            TextBox usernameBox = new TextBox();
            usernameBox.Location = new Point(100, 50);
            usernameBox.Width = 200;

            TextBox passwordBox = new TextBox();
            passwordBox.Location = new Point(100, 100);
            passwordBox.Width = 200;

            Label errorLabel = new Label();
            errorLabel.Location = new Point(100, 150);
            errorLabel.ForeColor = Color.Red;

            Button loginButton = new Button();
            loginButton.Text = "Bejelentkezés";
            loginButton.Location = new Point(100, 200);
            loginButton.Click += (s, ev) =>
            {
                if (usernameBox.Text == "admin" && passwordBox.Text == "admin")
                {
                    adminLoginForm.Close();
                    ShowAdminPanel();
                }
                else
                {
                    errorLabel.Text = "Rossz felhasználónév vagy jelszó!";
                }
            };

            adminLoginForm.Controls.Add(usernameBox);
            adminLoginForm.Controls.Add(passwordBox);
            adminLoginForm.Controls.Add(loginButton);
            adminLoginForm.Controls.Add(errorLabel);

            adminLoginForm.ShowDialog();
        }
    }
}
